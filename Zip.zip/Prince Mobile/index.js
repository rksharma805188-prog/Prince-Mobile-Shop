const slides = document.querySelector(".slides");
const images = document.querySelectorAll(".slides img");

let index = 0;

setInterval(() => {

index++;

if(index >= images.length){
index = 0;
}

const width = document.querySelector(".image-slider").clientWidth;

slides.style.transform = `translateX(-${index * width}px)`;

},5000);

const contactBtn = document.getElementById('contactbtn');
const contactDropdown = document.getElementById('contact-dropdown');

contactBtn.addEventListener('click', () => {
    contactDropdown.classList.toggle('active');
});

const form = document.querySelector('adminForm');
form.addEventListener('submit', function (event) {
    event.preventDefault(console.log('Form submitted')); // पेज रिफ्रेश रोकें
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    if (email === 'rksharma805188@gmail.com' && password === 'Raj@123') {
        window.location.href = 'Admin Dashboard.html';
    } else {
        alert('Worng Email or Password');
    }
});

